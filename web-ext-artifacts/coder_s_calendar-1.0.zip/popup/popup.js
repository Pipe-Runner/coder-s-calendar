console.log("Main script loaded");

// initializing contestList
refresh();

